
/**
 * Restful services here
 */
package com.mycompany.docavailabilityapp.service;