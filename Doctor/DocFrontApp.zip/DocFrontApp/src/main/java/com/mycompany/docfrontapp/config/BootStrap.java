package com.mycompany.docfrontapp.config;
import javax.ws.rs.ApplicationPath;

@SuppressWarnings({"EmptyClass", "SuppressionAnnotation"})
@ApplicationPath("rest")
public class BootStrap extends javax.ws.rs.core.Application {
}
